import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Real_Pong extends PApplet {

Ball ball; 

Paddle paddleLeft;
Paddle paddleRight;

int scoreLeft = 0;
int scoreRight = 0;
boolean play;

public void setup() {
  
  ball = new Ball(width/2, height/2, 25); 
  ball.speedX = 8; 
  ball.speedY = 8; 

  paddleLeft = new Paddle(75, height/2, 30, 200);
  paddleRight = new Paddle(width-75, height/2, 30, 200);
  play = false;
}

public void draw() {
  if (!play) {
    startScreen();
  } else {
    background(0); 
    ball.display(); 
    ball.move(); 
    ball.display(); 

    paddleLeft.move();
    paddleLeft.display();
    paddleRight.move();
    paddleRight.display();
    fill(0xff0300FF);
    stroke(255);
    line(400, 0, 400, 600);    
    ellipse(400, 300, 75, 75);
    line(780, 600, 780, 0);
    line(20, 600, 20, 0);
    line(700, 450, 700, 150);
    line(700, 450, 780, 450);
    line(700, 150, 780, 150);
    line(100, 450, 100, 150);
    line(100, 450, 20, 450);
    line(100, 150, 20, 150);

      if (ball.right() > 780) {
        scoreLeft = scoreLeft + 1;
        ball.x = width/2;
        ball.y = height/2;
      }
      if (ball.left() < 20) {
        scoreRight = scoreRight + 1;
        ball.x = width/2;
        ball.y = height/2;
      }
      if (ball.bottom() > height) {
        ball.speedY = -ball.speedY;
      }

      if (ball.top() < 0) {
        ball.speedY = -ball.speedY;
      }

      if (paddleLeft.bottom() > height) {
        paddleLeft.y = height-paddleLeft.h/2;
      }

      if (paddleLeft.top() < 0) {
        paddleLeft.y = paddleLeft.h/2;
      }

      if (paddleRight.bottom() > height) {
        paddleRight.y = height-paddleRight.h/2;
      }

      if (paddleRight.top() < 0) {
        paddleRight.y = paddleRight.h/2;
      }

      if ( ball.left() < paddleLeft.right() && ball.y > paddleLeft.top() && ball.y < paddleLeft.bottom()) {
        ball.speedX = -ball.speedX;
        ball.speedY = map(ball.y - paddleLeft.y, -paddleLeft.h/2, paddleLeft.h/2, -10, 10);
      }

      if ( ball.right() > paddleRight.left() && ball.y > paddleRight.top() && ball.y < paddleRight.bottom()) {
        ball.speedX = -ball.speedX;
        ball.speedY = map(ball.y - paddleRight.y, -paddleRight.h/2, paddleRight.h/2, -10, 10);
      }
      textSize(40);
      textAlign(CENTER);
      fill(0xff001BFF);
      text(scoreRight, width/2+30, 30); 
      text(scoreLeft, width/2-30, 30); 
    }
  }
  public void keyPressed() {
    if (keyCode == UP) {
      paddleRight.speedY=-10;
    }
    if (keyCode == DOWN) {
      paddleRight.speedY=10;
    }
    if (key == 'a') {
      paddleLeft.speedY=-10;
    }
    if (key == 'z') {
      paddleLeft.speedY=10;
    }
  }

  public void keyReleased() {
    if (keyCode == UP) {
      paddleRight.speedY=0;
    }
    if (keyCode == DOWN) {
      paddleRight.speedY=0;
    }
    if (key == 'a') {
      paddleLeft.speedY=0;
    }
    if (key == 'z') {
      paddleLeft.speedY=0;
    }
  }

  public void startScreen() {
    background(0);
    textAlign(CENTER);
    text("Up and down arrow keys control right paddle", width/2, height/2);
    text("A and Z control left padde", width/2, height/2+20);
    text("Click to continue", width/2, height/2+40);

    if (mousePressed) {
      play = true;
    }
  }
class Ball {
  float x;
  float y;
  float speedX;
  float speedY;
  float diameter;
  int c;
  
  
  Ball(float tempX, float tempY, float tempDiameter) {
    x = tempX;
    y = tempY;
    diameter = tempDiameter;
    speedX = 0;
    speedY = 0;
    c = (0xffFF8503); 
  }
  
  public void move() {
    
    y = y + speedY;
    x = x + speedX;
  }
  
  public void display() {
    fill(c); 
    ellipse(x,y,diameter,diameter); 
  }
  
 public float left(){
    return x-diameter/2;
  }
  public float right(){
    return x+diameter/2;
  }
  public float top(){
    return y-diameter/2;
  }
  public float bottom(){
    return y+diameter/2;
  }

}
class Paddle{

  float x;
  float y;
  float w;
  float h;
  float speedY;
  float speedX;
  int c;
  
  Paddle(float tempX, float tempY, float tempW, float tempH){
    x = tempX;
    y = tempY;
    w = tempW;
    h = tempH;
    speedY = 0;
    speedX = 0;
    c=(0xff03FF22);
  }

  public void move(){
    y += speedY;
    x += speedX;
  }

  public void display(){
    fill(c);
    rect(x-w/2,y-h/2,w,h);
  } 
  
public float left(){
    return x-w/2;
  }
  public float right(){
    return x+w/2;
  }
  public float top(){
    return y-h/2;
  }
  public float bottom(){
    return y+h/2;
  }
}
  public void settings() {  size(800, 600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Real_Pong" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
